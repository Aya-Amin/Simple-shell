#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

int builtIn_cd ( char** args)
{
    if ( args[1] == NULL)
        printf(stderr, "Missing argument: directory not specified\n");
    else
    {
        if ( chdir(args[1] != 0) )
            printf("Can't change the directory\n");
    }
    return 1;
}

int builtIn_help ()
{

    printf("Use the man command for information on other commands\n");
    return 1;
}

int builtIn_exit()
{
    return 0;
}

int shellExecute (char** command)
{

    pid_t pid, wpid;
    int status, i, n = sizeof(command) / sizeof(command[0]);

    pid = fork(); // When fork returns, we have 2 processes running concurrently.

    if( pid >= 0)   // fork() succeded
    {
        if ( pid == 0)   // Code of child
        {
//            if ( !strcmp(command[0], "exit") )
//                i = builtIn_exit();
//            else if ( !strcmp(command[0], "help") )
//                i = builtIn_help();
//            else if ( !strcmp(command[0], "cd") )
//                i = builtIn_cd(command);
//            else
                // execvp expects prog name & array of string arguments. P: instead of
                // providing the full file path of the program to be run, we're providing only
                // the prog name.
                // If exec command returns, the an error has occurred.
                i = execvp(command[0], command);
//                if ( i == -1 )  // Error executing child process
//                    perror("Error in executing  child process.");
//                exit(EXIT_FAILURE);
           }
        else //if ( strcmp(command[n-1], "&") )
        {
            wait(status);
            return 1;
        }
//        else
//            return 1;
   }
    else     // Error occurred in fork command
        perror("fork() has failed.");

    //      do       // Use waitpid to wait for the process's state to change.
    //      {
    //          wpid = waitpid(pid, &status, WUNTRACED); // Process can exit normally or by a signal, or it can be killed by a signal.
//  }
    //      while( !WIFEXITED(status) && !WIFSIGNALED(status) );
    return i;
}


int main()
{
    int i=0, bufSize = 64, loopVar;
    char **tokens = malloc(bufSize * sizeof(char*));
    char *line = malloc(bufSize * sizeof(char));
    char *token = malloc(10 * sizeof(char));


    do
    {
        printf("Shell > ");
        gets(line);

        if(!tokens)
        {
            printf(stderr,"Allocation Error \n");
            exit(EXIT_FAILURE);
        }

        token = strtok(line, " ");
        while(token != NULL)
        {
            tokens[i] = token;
            i++;

            if (i >= bufSize)
            {
                bufSize = bufSize + 64;
                tokens = realloc(tokens, bufSize * sizeof(char*));

                if(!tokens)
                {
                    printf(stderr,"Allocation Error \n");
                    exit(EXIT_FAILURE);
                }
            }
//            memset(line, 0, strlen(line));
//            memset(token, 0, strlen(line));
        }

        tokens[i] = NULL;
        loopVar = shellExecute(tokens);
    }
    while(loopVar);

    free(tokens);
    free (line);
    free(token);

    return 0;
}










